# weather-app
For this app to work you will need to go to https://openweathermap.org/ create an account and get a key.

I used MongoDB for the db.  If that's not your thing you may have to retool some code to get it to work.


Continue to research gifs to represent the weather.

# Mountain Quotes:
• It might be fun to add quotes the app on the main page or current weather page. 
• I can make an api with quotes and access them at random to display. Or it could be in the db.
https://www.wedreamoftravel.com/top-mountain-quotes/